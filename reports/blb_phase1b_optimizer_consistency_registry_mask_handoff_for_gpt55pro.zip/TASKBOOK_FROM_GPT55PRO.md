# Codex Phase-1B Taskbook: Optimizer-Cost Consistency, Registry Integrity, Mask Repair, Then Current-Code Server Smoke

## Role and context

You are executing code work for a long-running BLB Stage-2 RL optimization project. Do not chase a quick best reward. This phase is still about making future training results trustworthy and comparable.

The current project goal is fixed: BLB Stage-2 RL selects action indices for every CKKS scaling-factor slot in the BLB five-block computation graph, plus block-end truncation-bit indices for MPC/CKKS conversion simulation. The RL action is an index. The index is decoded to a scaling factor or truncation k. The operation slots are not optional.

Current package state from the previous handoff:

- Action vector shape is still `73 * L + 1`; for MRPC/BERT-base with `L=12`, width is `877`.
- The current code semantically marks layer-0 block1 and `first_input_sf` as ineffective/no-op compatibility slots.
- F0 local scan reports all-max optimizer baseline `total_bits_sum=14779`, `fusion_count=0`.
- No current-code server/GPU F1 smoke has been run after the layer-0 flow change.
- This taskbook intentionally blocks long training.

## Phase-1B decision

Do not run long RL training.

Before any F1/F2 optimization, fix the Phase-1 evidence integrity problem: the current F0 scan appears to compare the all-max baseline through `evaluate_baseline_blocks(...)`, while candidate actions go through `evaluate_blocks(...)`. In the previous handoff, mutating an ineffective layer-0 block1 slot still changed `total_bits_sum` from `14779` to about `14889`. Since that slot is declared ineffective and not sent to Rescale_optimizer, this should not happen. It suggests either an evaluation-mode mismatch, an artifact-generation bug, or a cost-baseline convention mismatch.

This phase is successful only when the following invariant holds:

```text
same effective BLB cfg + same optimizer context => same optimizer_valid, total_bits_sum, fusion_count, q diagnostics
```

Raw action indices may differ in ineffective compatibility slots, but effective cost and model behavior must not differ.

## Non-negotiable constraints

1. Do not change the action vector width from `877` for MRPC/BERT-base.
2. Do not delete action slots from the policy/action vector. Ineffective compatibility slots may be baseline-only masked, but they must remain in the vector.
3. Do not mix Rescale_optimizer cost with truncation cost. Rescale cost is only `total_bits_sum` and `fusion_count`.
4. `invalid_chain` is a hard validity gate, not numeric cost.
5. `q_bits`, `q_head_bits`, and `q_tail_bits` are diagnostics only.
6. Loss is not a final hard feasible constraint for MRPC. Hard metrics are Acc and F1 mean/std. This phase, however, is mostly F0/F1 diagnostic, not final feasibility.
7. Mask is curriculum, not final search-space deletion.
8. All reports must explicitly say whether results are current-code, real in-process Rescale_optimizer, diagnostic feasible or formal feasible, and comparable or not.

## Work item 1: Add optimizer-mode consistency diagnostics

Create one of the following:

```text
scripts/blb_compare_optimizer_modes.py
```

or a clearly named equivalent script under `scripts/`.

It must run on MRPC/BERT-base with the current Stage-1 config and compare at least these actions:

1. `all_max_raw`: exact `make_all_max_action_vector(L)`.
2. `all_max_via_candidate_path`: the same action, but evaluated through the ordinary candidate path, not `evaluate_baseline_blocks`.
3. `inactive_l0b1_mutation`: mutate one layer-0 block1 inactive slot away from baseline.
4. `inactive_first_input_mutation`: mutate the tail `first_input_sf` inactive slot away from baseline.
5. `effective_single_mutation`: mutate one known effective slot near baseline.

For each action, report:

```text
raw_action_hash
effective_action_hash, if implemented; otherwise explain missing
request_count
request_keys sorted
whether block1_mrpc_L0 is sent
whether first_input is sent
optimizer_eval_mode: evaluate_baseline_blocks or evaluate_blocks
t_new_source per config if available
per-config total_bits, fusion_count, valid, invalid_chain, q_bits, q_head_bits, q_tail_bits
aggregate total_bits_sum, fusion_count, optimizer_valid
```

Write outputs to:

```text
reports/blb_opt/phase1b_consistency/optimizer_mode_comparison.json
reports/blb_opt/phase1b_consistency/optimizer_mode_comparison.md
```

The markdown must include a pass/fail table for these invariants:

```text
all_max baseline path == all_max candidate path
inactive_l0b1_mutation == all_max candidate path
inactive_first_input_mutation == all_max candidate path
effective_single_mutation may differ from all_max candidate path
```

If any no-op/inactive mutation differs from all-max candidate path, stop before training and fix.

## Work item 2: Fix the cost-evaluation convention

The previous F0 artifact is not sufficient evidence because all-max may have been evaluated through `evaluate_baseline_blocks`, while candidates were evaluated through `evaluate_blocks`.

Choose one canonical convention and make it explicit in code and reports.

Preferred convention:

```text
For candidate ranking, reward baseline, F0 scan, and RL env cost comparison, evaluate all actions, including all-max, through the same cfg-derived action path.
```

This means all-max should be passed through the same `action_vector_to_cfgs -> build_optimizer_requests -> evaluate_blocks` path as other actions. If a separate `evaluate_baseline_blocks` path is retained, it is diagnostic/handover only and must be compared against the canonical action path, not silently mixed in candidate ranking.

Alternative convention is acceptable only if you prove and enforce:

```text
evaluate_baseline_blocks(all_max requests) == evaluate_blocks(all_max cfg-derived requests)
```

If the two paths are not equal, do not mix them.

Concrete implementation requirements:

- Add a helper or wrapper such as `evaluate_action_for_cost(...)` that has one obvious convention.
- Use the same convention in `scripts/blb_f0_scan_feasible_domain.py` for baseline and candidates.
- Use the same convention in `BLBStage2Env.step(...)` and `estimate_baseline_cost_stats(...)`, or explicitly report and justify any difference.
- Add a regression test that fails if all-max baseline and all-max candidate path produce different aggregate cost under the chosen convention.

Suggested test file:

```text
tests/test_blb_optimizer_cost_consistency.py
```

At minimum test the pure Python/request-side invariant even if a full Rescale_optimizer call is too expensive locally:

```text
- layer0 block1 is not in optimizer requests
- first_input is not in optimizer requests
- mutating ineffective slots yields identical optimizer requests
- mutating effective slots may yield different cfg/t_new/overrides
```

If you can run in-process RO in the test without making tests slow or flaky, also assert aggregate cost equality for no-op mutations.

## Work item 3: Add effective action identity

Current candidate identity must distinguish raw action vector from effective behavior.

Add or update helpers in `blb_stage2_rl/candidate_store.py` or a nearby module:

```text
raw_action_hash(action_vec)
effective_action_vector(action_vec, registry/description, baseline_action)
effective_action_hash(action_vec, registry/description, baseline_action)
```

The effective action vector should normalize ineffective compatibility slots to the baseline action index. This makes actions that differ only in no-op slots share an effective identity.

Candidate records should include:

```json
{
  "raw_action_hash": "...",
  "effective_action_hash": "...",
  "candidate_key": "...",
  "candidate_key_basis": "effective_action_hash + identity_context",
  "raw_action_indices": [...],
  "effective_action_indices": [...]
}
```

Use the effective hash for cost/evaluation cache identity when ineffective slots cannot change model or optimizer behavior. Keep raw hash for debugging and reproducibility.

Add tests:

```text
- layer0 block1 mutation changes raw_action_hash but not effective_action_hash
- first_input mutation changes raw_action_hash but not effective_action_hash
- effective slot mutation changes both raw_action_hash and effective_action_hash
```

## Work item 4: Repair F0 scan and mask generation

Update `scripts/blb_f0_scan_feasible_domain.py` so that its output is trustworthy after Work items 1-3.

Required changes:

1. Use the canonical cost evaluator from Work item 2 for both baseline and all candidates.
2. Do not evaluate or open ineffective slots as if they were meaningful. For ineffective slots, the suggested mask must be baseline-only with reason:

```text
ineffective_compat_slot_baseline_only
```

3. For K/truncation slots, do not use F0 optimizer validity as proof that all K values are safe. K affects model precision/communication, not Rescale_optimizer cost. For this phase, use a conservative K mask such as:

```text
k=13 baseline, optionally k=12 and k=11 if present
```

Record the exact allowed K values and reason. Do not open `k=8/9/10` until F1/F2 model evidence supports it.

4. `masked_random_validity.json` must report cost distribution, not only validity:

```json
{
  "mutation_count": 1,
  "attempted": 50,
  "valid": 50,
  "valid_rate": 1.0,
  "total_bits_min": ...,
  "total_bits_mean": ...,
  "total_bits_max": ...,
  "fusion_count_min": ...,
  "fusion_count_mean": ...,
  "fusion_count_max": ...,
  "best_action_hashes": [...]
}
```

5. Beam scan must not seed only single-slot cost-improving mutations. The previous F0 found no single-slot cost-improving mutations, which does not prove there is no multi-slot improvement. Add a small multi-slot exploration mode:

```text
--multi-random-samples 500
--multi-mutation-counts 2,4,8,16,32
```

This remains optimizer-only. It should record best valid candidates by `[total_bits_sum, fusion_count]`, even if no improvement is found.

6. Output refreshed artifacts to:

```text
reports/blb_opt/phase1b_f0_scan/
```

Do not overwrite the previous Phase-1 F0 folder.

## Work item 5: Fix registry artifact consistency

The previous package contained inconsistent registry artifacts: `current_code_action_registry.json` marked layer-0 block1 and first_input as ineffective, but standalone `slot_registry_full.json` still contained stale effective flags.

Fix export tooling so every registry artifact agrees.

Required checks:

```text
current_code_action_registry.json["slot_registry_full"] == slot_registry_full.json
current_code_action_registry.json["slot_registry_effective"] == slot_registry_effective.json
layer0 block1 slots are ineffective in all registry outputs
first_input slot is ineffective in all registry outputs
slot_registry_effective.json excludes layer0 block1 and first_input
```

Add a regression test or validation script:

```text
tests/test_blb_registry_artifact_consistency.py
```

or include this validation in `scripts/blb_export_action_registry.py` and run it in the package process.

## Work item 6: Mask diagnostics in runner and policy

The current policy supports `action_mask` and `action_bias`, but diagnostics must be made harder to misread.

Required changes:

1. Ensure `policy.per_dim_entropy(...)` can accept `action_mask` and `action_bias`, or add a separate `per_dim_entropy_masked(...)` helper.
2. Runner logs should clearly distinguish:

```text
raw_entropy_by_kind
masked_entropy_by_kind
```

If only masked entropy is available, name it `masked_entropy_by_kind`; do not call it just `entropy_by_kind`.

3. When loading a mask file, runner must warn or fail if any ineffective slot allows a non-baseline index.

4. Every episode trace row should include:

```text
action_source: anchor / cost_probe / neighbor / policy_masked / policy_unmasked
action_mask_hash
action_bias_bonus
mutated_slot_count
mutated_effective_slot_count
mutated_ineffective_slot_count
```

If these fields already exist partially, complete them and verify they are written in `blb_stage2_episode_trace.csv`.

## Work item 7: Server sync and current-code smoke gate

After the local consistency fixes pass, sync the exact current working tree to the server. Use the conda environment `llm_ist`.

Server environment variables for MRPC:

```bash
export HF_ENDPOINT=https://hf-mirror.com
export HF_HOME=/var/tmp/root-home/.cache/huggingface
export GLUE_LOCAL_DATASET_DIR=/var/tmp/root-home/.cache/huggingface/datasets/glue/mrpc/0.0.0/1edab70c7fdff5d2
```

Before running smoke, write:

```text
reports/server_code_sync_report.md
reports/server_code_sync_report.json
```

They must include:

```text
server git HEAD
server tracked diff hash
server untracked file list summary
server Rescale_optimizer canonical hash
server registry hash
server max_sfs hash
server stage1 content hash
whether these match local package values
```

Then run focused tests on server:

```bash
python -m unittest \
  tests.test_blb_baseline_bootstrap \
  tests.test_blb_stage2_rl_regressions \
  tests.test_blb_action_mask \
  tests.test_blb_candidate_store_identity \
  tests.test_blb_cost_semantics \
  tests.test_blb_f0_scan \
  tests.test_blb_optimizer_cost_consistency \
  tests.test_blb_registry_artifact_consistency
```

Run py_compile for changed Python files.

Only after tests pass, run a short current-code F1 masked smoke. Use the Phase-1B mask generated in Work item 4.

Recommended smoke shape:

```text
240 to 480 episodes
rollout size small enough to get multiple PPO updates
probe size 16 or 32
k_trials 1 for smoke only
mask mode from_file
mask file reports/blb_opt/phase1b_f0_scan/suggested_action_mask.json
baseline logit bonus 5.5
warmstart anchor enabled
neighbor sampling enabled if current code supports it
```

Do not run long training.

Smoke success gate:

```text
- no error_summary.txt
- baseline preflight passes
- action mask loads and hash is logged
- non-anchor invalid rate <= 50% minimum, <= 30% target
- no inactive slot mutation affects optimizer cost
- if a best reward appears, report it as diagnostic only, not final evidence
```

If non-anchor invalid rate is still above 50%, stop and package diagnostics. Do not increase episodes.

## Work item 8: Package deliverables

Return a zip with the usual code-state envelope. It must contain:

```text
README_FOR_GPT55PRO.md
RESULT_CREDIBILITY_PAGE.md
_sync_metadata/git_head.txt
_sync_metadata/git_diff.patch
_sync_metadata/git_diff_stat.txt
_sync_metadata/git_status.txt
_sync_metadata/git_untracked_files.txt
_sync_metadata/sha256sums.txt
reports/blb_opt/phase1b_consistency/optimizer_mode_comparison.json
reports/blb_opt/phase1b_consistency/optimizer_mode_comparison.md
reports/blb_opt/phase1b_f0_scan/*
reports/blb_opt/phase1b_registry/* or refreshed phase1 registry with consistency proof
reports/phase1b_result_summary.json
reports/phase1b_result_summary.md
reports/phase1b_remote_test_log.txt if server tests run
reports/phase1b_smoke_summary.json if F1 smoke run
reports/phase1b_smoke_summary.md if F1 smoke run
server run artifacts if smoke run
```

The README must answer these four questions explicitly:

1. Did these results come from the current packaged code?
2. Did these results use real in-process Rescale_optimizer?
3. Are these results formal feasible, strict feasible, or diagnostic only?
4. Can these results be compared with the previous handoff? If yes, under which identity hashes?

## Stop conditions

Stop and return diagnostics instead of continuing if any of these happens:

```text
- all-max baseline path and all-max candidate path disagree and you have not fixed it
- ineffective slot mutation changes effective optimizer requests/cost after your fix
- registry artifacts disagree with each other
- server code hash does not match local package hash before smoke
- mask file opens ineffective slots to non-baseline indices
- F1 smoke invalid rate remains above 50%
- final reports cannot say whether a result is current-code evidence
```

## What not to do

- Do not start long training.
- Do not report F0 validity as model feasibility.
- Do not silently change feasible thresholds.
- Do not mix old Trust-0 candidate stores with the current registry hash.
- Do not use heuristic Rescale_optimizer for any F0/F1 result in this phase.
- Do not remove layer/action slots from the action vector.
- Do not let no-op compatibility slots remain freely mutable in the Phase-1B mask.
