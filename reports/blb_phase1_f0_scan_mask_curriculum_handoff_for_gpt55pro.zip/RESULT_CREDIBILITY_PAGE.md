# Result Credibility Page

## 1. Did these results come from the current packaged code?

Limited yes. The local F0 artifacts, registry, manifest, layer-0 flow smoke, and focused tests were regenerated after Claude's layer-0 block1 / first_input change and Codex's follow-up fix. No server/GPU training result exists from this code.

Implication: use these as current local optimizer-only evidence, not as training evidence.

## 2. Did these results use the real in-process Rescale_optimizer?

Yes for F0. The refreshed F0 scan used `rescale_optimizer_mode=in_process_real` and local `Rescale_optimizer` canonical hash `ed28392d4078e4eb7734740023d281d5b87f1abde68340d7776f4e2855e4278e`.

Implication: F0 optimizer validity and cost numbers are from real RO, not the heuristic stub.

## 3. Are these results formally feasible, or only diagnostically feasible?

Limited: diagnostic feasible only. The F0 result proves optimizer-only feasibility for the scanned/masked action domain. It does not prove model accuracy/stability, real BLB install behavior, repeated evaluation stability, or final-eval formal feasibility.

Implication: do not enter long training on F0 alone.

## 4. Can these results be compared with the previous results?

Limited. They can be compared only as a deliberate identity-space transition: layer-0 block1 and first_input were removed from effective semantics, so the registry hash, baseline bits, and mask hash changed.

Current identity:

- registry hash: `6c3662ba26160952e27dca8a8e3ae164af8326ac01819677c7b1a453fe342412`
- max_sfs hash: `bee17f0ccab949b79b4ca011a97da4cebd1d749e6ad49bffa272a701895e09f6`
- Stage-1 config hash: `6454e0556f54ddb4519d9d2998582bca40a41fe2910d2ece679e455f8854eed3`
- Rescale_optimizer canonical hash: `ed28392d4078e4eb7734740023d281d5b87f1abde68340d7776f4e2855e4278e`
- F0 baseline bits: `14779`
- mask hash: `2dda3a20ce9339f9fc95f164b88226f92d543debc2a0f38762f7b1312f4e870e`

Implication: do not mix rankings/candidate stores from the older registry hash `3b1eb99dae044bfb96237f27402b851ea43dee5870eb241339485739b4effe4b` with this package.

## Long-Train Gate

Do not enter long training until server sync and at least one current-code F1 GPU smoke are completed.
