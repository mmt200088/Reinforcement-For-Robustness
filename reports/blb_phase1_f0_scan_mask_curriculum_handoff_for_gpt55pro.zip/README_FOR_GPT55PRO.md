# From Codex: Phase-1 F0 Package + Claude Layer-0 Flow Update

## It Executed The Task

This package refreshes the code handoff after Claude's process-level change:

- Keep the action-vector layout unchanged: `73 * L + 1`, so MRPC `L=12` still has `877` dims.
- Semantically disable layer-0 block1 and first_input fresh noise.
- Keep layer-0 block2 fully active.
- Align RO requests and baseline handover with `5L - 1` blocks, while tolerating old RO responses that still include `(block=1, layer=0)`.

Codex inspected the change, added/updated regression coverage, found one stale F0 baseline sanity constant, fixed it from `14989` to `14779`, regenerated registry/manifest/F0 artifacts, and rebuilt this zip.

No GPU training was run in this refresh.

## Current Git HEAD

- local HEAD: `6341ceab2bb15cd6e4cb0b98805bc88d7343a984`
- branch: `jk_standard_rl`
- local upstream `origin/jk_standard_rl`: `6341ceab2bb15cd6e4cb0b98805bc88d7343a984`
- server HEAD: not confirmed; non-interactive SSH currently returns `Permission denied (publickey,password)`

## Current Diff Hash

- tracked diff hash after this refresh: `4c333753e92e5bfcdb2a97e9b288f37bef7b0413`
- manifest-time tracked diff hash in `reports/blb_opt/phase1_manifest/run_manifest.json`: `0bc94c1f860e75850be968a178f9df68d15be5b4b670505465464ffd207217d2`

The implementation-affecting F0 artifacts were regenerated after the layer-0 flow change. The handoff zip SHA is the package-level identity for untracked files.

## Uncommitted Changes

Yes. The working tree is intentionally dirty with code, tests, generated reports, and handoff files. See:

- `_sync_metadata/git_status.txt`
- `_sync_metadata/git_diff_stat.txt`
- `_sync_metadata/git_untracked_files.txt`
- `_sync_metadata/git_diff.patch`

## Result Credibility Page

Path: `RESULT_CREDIBILITY_PAGE.md`

Four-question summary:

- Current packaged code: Limited yes. Local F0/tests are current; server/GPU training is not current.
- Real in-process Rescale_optimizer: Yes for F0.
- Formal feasible vs diagnostic feasible: Diagnostic only.
- Comparable with previous results: Limited. The identity changed because registry hash and baseline bits changed after layer-0 block1 removal.

## Files Changed This Round

Claude flow changes:

- `blb_stage2_rl/action_space.py`
- `blb_rl_bridge.py`
- `function_handler.py`
- `blb_stage2_rl/env.py`
- `Paean/blb_action_eval.py`
- `blb_stage2_rl/baseline_bootstrap.py`
- `docs/blb_baseline_handover_protocol.md`
- `docs/blb_rl_to_rescale_optimizer_mapping.md`
- `CLAUDE.md`
- `tests/test_blb_stage2_rl_regressions.py`

Codex follow-up changes:

- `tests/test_blb_baseline_bootstrap.py`
- `scripts/blb_f0_scan_feasible_domain.py`
- regenerated `reports/blb_opt/phase1_registry/*`
- regenerated `reports/blb_opt/phase1_manifest/*`
- regenerated `reports/blb_opt/phase1_f0_scan/*`
- refreshed `README_FOR_GPT55PRO.md`, `RESULT_CREDIBILITY_PAGE.md`, `reports/phase1_result_summary.*`, `reports/phase1_remote_test_log.txt`, `_sync_metadata/*`

Existing Phase-1 files still included in this package:

- `blb_stage2_rl/action_mask.py`
- `blb_stage2_rl/feasibility.py`
- `blb_stage2_rl/candidate_store.py`
- `blb_stage2_rl/policy.py`
- `blb_stage2_rl/persistence.py`
- `blb_stage2_rl/runner.py`
- `scripts/blb_eval_action.py`
- `scripts/blb_export_action_registry.py`
- `scripts/blb_make_run_manifest.py`
- `rl_tune.py`
- `layer_importance_evaluator.py`
- `llama_7B_LayerImportance.sh`

## Which Results Come From Current Code

Current local code results:

- `reports/blb_opt/phase1_registry/*`
- `reports/blb_opt/phase1_manifest/*`
- `reports/blb_opt/phase1_f0_scan/*`
- 49-test focused local verification in `reports/phase1_remote_test_log.txt`
- layer-0 flow smoke result in `reports/phase1_remote_test_log.txt`

Old-code / previous-round reference only:

- `reports/trust0_*`
- `reports/blb_opt/trust0_*`
- any long RL training result produced before Claude's flow change

## Commands Run

Local verification:

```bash
python -m unittest tests.test_blb_baseline_bootstrap tests.test_blb_stage2_rl_regressions tests.test_blb_action_mask tests.test_blb_candidate_store_identity tests.test_blb_cost_semantics tests.test_blb_f0_scan
python -m py_compile blb_stage2_rl/action_space.py blb_rl_bridge.py function_handler.py blb_stage2_rl/env.py Paean/blb_action_eval.py blb_stage2_rl/baseline_bootstrap.py scripts/blb_f0_scan_feasible_domain.py tests/test_blb_baseline_bootstrap.py
git diff --check
```

Layer-0 flow smoke:

```bash
python - <<'PY'
from blb_stage2_rl.action_space import action_vector_to_cfgs, build_optimizer_requests, describe_action_vector, load_max_sfs, make_all_max_action_vector
max_sfs = load_max_sfs("mrpc")
action = make_all_max_action_vector(3)
decoded = action_vector_to_cfgs(action, max_sfs=max_sfs, num_layers=3, gelu_degree=[1,1,1], attn_degree=[2,2,2])
requests = build_optimizer_requests("mrpc", decoded.cfgs_dict())
desc = describe_action_vector(action, max_sfs=max_sfs, num_layers=3, gelu_degree=[1,1,1], attn_degree=[2,2,2], profile="mrpc")
PY
```

Fresh local artifacts:

```bash
python scripts/blb_export_action_registry.py --profile mrpc --num-layers 12 --fixed-gelu 1,1,1,1,1,4,1,1,1,1,1,1 --fixed-softmax 2,2,5,5,5,2,5,2,5,5,6,2 --expected-slots-per-layer 73 --output-dir reports/blb_opt/phase1_registry
python scripts/blb_make_run_manifest.py --output-dir reports/blb_opt/phase1_manifest --profile mrpc --num-layers 12 --dataset mrpc --model bert-base --registry-path reports/blb_opt/phase1_registry/current_code_action_registry.json --max-sfs-path blb_stage2_rl/max_sfs/mrpc.json --stage1-config-path glue_final_configs_best_ppo.json --stage1-source glue_final_configs_best_ppo.json --rescale-optimizer-root Rescale_optimizer --rescale-optimizer-mode in_process_real --threshold-source smoke_temporary
python scripts/blb_f0_scan_feasible_domain.py --profile mrpc --model bert-base --num-layers 12 --stage1-config glue_final_configs_best_ppo.json --fixed-gelu 1,1,1,1,1,4,1,1,1,1,1,1 --fixed-softmax 2,2,5,5,5,2,5,2,5,5,6,2 --rescale-optimizer-root Rescale_optimizer --output-dir reports/blb_opt/phase1_f0_scan --beam-size 32 --beam-depths 1,2,4,8 --random-samples 200 --random-seed 42 --registry-hash 6c3662ba26160952e27dca8a8e3ae164af8326ac01819677c7b1a453fe342412 --max-sfs-hash bee17f0ccab949b79b4ca011a97da4cebd1d749e6ad49bffa272a701895e09f6
```

SSH probe:

```bash
ssh -o BatchMode=yes -o ConnectTimeout=12 100.84.74.99 "cd /var/tmp/root-home/Reinforcement-For-Robustness && pwd && git rev-parse HEAD"
```

## Environment Variables

Local F0 scan used local Windows Python. No special local env vars were required.

Server env for future smoke, not used in this refresh:

```bash
HF_ENDPOINT=https://hf-mirror.com
HF_HOME=/var/tmp/root-home/.cache/huggingface
GLUE_LOCAL_DATASET_DIR=/var/tmp/root-home/.cache/huggingface/datasets/glue/mrpc/0.0.0/1edab70c7fdff5d2
```

## Data Source

- dataset/profile: `mrpc`
- model: `bert-base`
- Stage-1 config source: `glue_final_configs_best_ppo.json`
- Stage-1 config content hash: `6454e0556f54ddb4519d9d2998582bca40a41fe2910d2ece679e455f8854eed3`
- Stage-1 GELU: `[1,1,1,1,1,4,1,1,1,1,1,1]`
- Stage-1 Softmax: `[2,2,5,5,5,2,5,2,5,5,6,2]`

## Rescale Optimizer

- mode: `in_process_real`
- local root: `Rescale_optimizer`
- canonical hash: `ed28392d4078e4eb7734740023d281d5b87f1abde68340d7776f4e2855e4278e`
- full tree hash from manifest: `99b6d9dffc0561c1982e905d16852f244c5e32e1f5b0e4ecbce72fbfeec25207`

## Stage-1 Configuration Source

- source file: `glue_final_configs_best_ppo.json`
- source hash: `6454e0556f54ddb4519d9d2998582bca40a41fe2910d2ece679e455f8854eed3`
- validated degree ranges in baseline handover:
  - GELU: `{1,2,4}`
  - Softmax: `{2,3,4,5,6}`

## Action Registry Hash

- action_space_version: `current-code-v1`
- decode_version: `action_space_v1`
- action width: `877`
- per-layer slots: `73`
- required/effective slot count: `791`
- ineffective or compat-extra slot count: `86`
- registry hash: `6c3662ba26160952e27dca8a8e3ae164af8326ac01819677c7b1a453fe342412`

## Max SFS Hash

- path: `blb_stage2_rl/max_sfs/mrpc.json`
- hash: `bee17f0ccab949b79b4ca011a97da4cebd1d749e6ad49bffa272a701895e09f6`

## Test Results

- Focused local unittest: `49 tests OK`
- `py_compile`: passed
- `git diff --check`: passed; Windows CRLF warnings only
- Python JSON parse of regenerated registry artifacts: passed
- Full GPU/server smoke: not run

Layer-0 flow smoke output:

```text
action_dim=220
block1_cfg_keys=[1, 2]
first_input_sf=0
request_count=14
has_block1_mrpc_L0=False
l0_block1_records=9
l0_block1_all_ineffective=True
first_input_effective=False
```

## F0 Result

F0 means optimizer-only diagnostic, no model execution.

- all-max baseline: `optimizer_valid=True`
- `total_bits_sum=14779`
- `fusion_count=0`
- `avg_k=13.0`
- `mask_hash=2dda3a20ce9339f9fc95f164b88226f92d543debc2a0f38762f7b1312f4e870e`
- masked random validity:
  - mutation_count=1: `50/50 = 1.0`
  - mutation_count=2: `50/50 = 1.0`
  - mutation_count=4: `50/50 = 1.0`
  - mutation_count=8: `50/50 = 1.0`

Baseline changed from the previous `14989` because `(block=1, layer=0)` is no longer sent to RO.

## Training Results

No current-code RL training result exists after Claude's layer-0 flow change.

Do not compare previous long-training curves as current-code evidence. Those are old-code observations only.

## Errors Or Exceptions

- Initial F0 rerun failed because `scripts/blb_f0_scan_feasible_domain.py` still expected old baseline bits `14989`; Codex updated the default to current `14779` and reran F0 successfully.
- Non-interactive SSH now reaches authentication but fails with `Permission denied (publickey,password)`. No server sync/test result is claimed.
- Local `bash -n` is not meaningful on this Windows host because `bash` resolves to unavailable WSL.

## Codex Summary And Suggestions

The package now reflects the current layer-0 semantics: action shape is checkpoint-compatible, but layer-0 block1 and first_input fresh are semantic no-ops and excluded from RO execution. This changes the candidate identity space through the registry hash and F0 baseline, so previous F0 masks/candidates must be treated as old identity space.

Before long training, sync this exact package to the server using a non-interactive SSH path or an explicit secure password-capable tool, then run current-code F1 GPU smoke.

## Supervisor Questions / Uncertainty

- Codex verified the changed local code path and F0; Codex did not run GPU/server training.
- Non-interactive SSH still cannot authenticate, so server state is not confirmed.
- The JSON handover reader tolerates old 5L RO responses, but the canonical expected response is now `5L - 1`.
