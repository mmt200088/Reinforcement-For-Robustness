"""BLB Stage-2 baseline JSON handover —— RL side.

实现 ``docs/blb_baseline_handover_protocol.md`` v1：

  * ``write_baseline_request(...)``  → 把 Stage-1 配置序列化为请求 JSON
  * ``read_baseline_response(...)``  → 读取 Rescale_optimizer 写的响应 JSON
                                        并校验 schema / request_id 一致性
  * ``baseline_response_to_cost_stats(...)`` → 把响应转换成
                                                ``BaselineCostStats``，可直接
                                                喂给 ``BLBStage2Env``
  * ``handover_paths(repo_root, dataset)`` → 标准路径辅助

设计目标：
  1. **不引入新依赖**：纯标准库 + numpy。
  2. **failed-block tolerance**：响应里某条 (block, layer) 失败时，向上层抛
     可读异常（caller 可决定是否启动训练）。
  3. **schema 自检**：版本不匹配立即拒绝，而不是带病往下走。
  4. 不实现"通知机制"（人工 / 文件 watch / CI）—— 那是部署侧选择。
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Mapping, Optional, Sequence

import numpy as np

from .reward import BaselineCostStats


# ---------------------------------------------------------------------------
# Schema 常量
# ---------------------------------------------------------------------------
REQUEST_SCHEMA_V1 = "blb_baseline_request_v1"
RESPONSE_SCHEMA_V1 = "blb_baseline_response_v1"

HANDOVER_DIRNAME = "handover"
REQUEST_FILENAME_FMT = "baseline_request_{dataset}.json"
RESPONSE_FILENAME_FMT = "baseline_response_{dataset}.json"

# Stage-1 取值范围（与协议第 2 节一致）
ALLOWED_GELU_DEGREES = (1, 2, 4)
ALLOWED_SOFTMAX_DEGREES = (2, 3, 4, 5, 6)


# ---------------------------------------------------------------------------
# 路径辅助
# ---------------------------------------------------------------------------
def handover_paths(repo_root: str, dataset: str) -> Dict[str, str]:
    """返回 ``{request_path, response_path, dir}``，路径都 join 过 repo_root。"""
    root = os.path.abspath(str(repo_root))
    handover_dir = os.path.join(root, HANDOVER_DIRNAME)
    return {
        "dir": handover_dir,
        "request_path": os.path.join(
            handover_dir, REQUEST_FILENAME_FMT.format(dataset=str(dataset)),
        ),
        "response_path": os.path.join(
            handover_dir, RESPONSE_FILENAME_FMT.format(dataset=str(dataset)),
        ),
    }


# ---------------------------------------------------------------------------
# Request 写入
# ---------------------------------------------------------------------------
def _validate_stage1(
        gelu_per_layer: Sequence[int],
        softmax_per_layer: Sequence[int],
        num_layers: int,
        ) -> None:
    if len(gelu_per_layer) != int(num_layers):
        raise ValueError(
            f"gelu_degree_per_layer length {len(gelu_per_layer)} != num_layers {num_layers}"
        )
    if len(softmax_per_layer) != int(num_layers):
        raise ValueError(
            f"softmax_degree_per_layer length {len(softmax_per_layer)} != num_layers {num_layers}"
        )
    bad_gelu = [int(d) for d in gelu_per_layer if int(d) not in ALLOWED_GELU_DEGREES]
    if bad_gelu:
        raise ValueError(
            f"gelu_degree_per_layer contains values outside {ALLOWED_GELU_DEGREES}: {bad_gelu}"
        )
    bad_sm = [int(d) for d in softmax_per_layer if int(d) not in ALLOWED_SOFTMAX_DEGREES]
    if bad_sm:
        raise ValueError(
            f"softmax_degree_per_layer contains values outside {ALLOWED_SOFTMAX_DEGREES}: {bad_sm}"
        )


def _generate_request_id(dataset: str, model: str) -> str:
    """``<YYYYMMDD-HHMMSS>-<dataset>-<model>``，便于多请求并存追踪。"""
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    return f"{stamp}-{str(dataset)}-{str(model)}"


def _git_commit_short(repo_root: str) -> str:
    """``git rev-parse --short HEAD``；失败返回空字符串（不阻塞 baseline）。"""
    try:
        import subprocess
        out = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=str(repo_root),
            capture_output=True, text=True, timeout=5.0,
        )
        if out.returncode == 0:
            return str(out.stdout).strip()
    except Exception:
        pass
    return ""


def write_baseline_request(
        repo_root: str,
        dataset: str,
        stage1_gelu_per_layer: Sequence[int],
        stage1_softmax_per_layer: Sequence[int],
        *,
        num_layers: Optional[int] = None,
        model: str = "bert-base",
        request_id: Optional[str] = None,
        rl_max_sfs: Optional[Mapping[str, Mapping[str, int]]] = None,
        rl_max_fresh_sfs: Optional[Mapping[str, int]] = None,
        rl_max_truncation_k: int = 13,
        blb_first_input_N: int = 8192,
        ) -> str:
    """把 Stage-1 配置写成 baseline_request JSON，返回写入路径。

    Args:
        repo_root: 项目根目录
        dataset:   GLUE 任务名（决定 graph 文件 block1_<dataset>.json 等）
        stage1_gelu_per_layer:    长度 num_layers，元素 ∈ {1,2,4}
        stage1_softmax_per_layer: 长度 num_layers，元素 ∈ {2..6}
        num_layers:               缺省取两个序列长度的较小者
        model / request_id / 其余字段：见
            ``docs/blb_baseline_handover_protocol.md`` §2

    Raises:
        ValueError: Stage-1 配置长度 / 取值不合法
    """
    if num_layers is None:
        num_layers = min(len(stage1_gelu_per_layer), len(stage1_softmax_per_layer))
    _validate_stage1(stage1_gelu_per_layer, stage1_softmax_per_layer, int(num_layers))

    paths = handover_paths(repo_root, dataset)
    os.makedirs(paths["dir"], exist_ok=True)

    if request_id is None:
        request_id = _generate_request_id(dataset, model)

    payload: Dict[str, Any] = {
        "schema": REQUEST_SCHEMA_V1,
        "request_id": str(request_id),
        "dataset": str(dataset),
        "model": str(model),
        "num_layers": int(num_layers),
        "stage1_config": {
            "gelu_degree_per_layer":
                [int(d) for d in stage1_gelu_per_layer],
            "softmax_degree_per_layer":
                [int(d) for d in stage1_softmax_per_layer],
        },
        "rl_max_truncation_k": int(rl_max_truncation_k),
        "blb_first_input_N": int(blb_first_input_N),
        "rl_repo_commit": _git_commit_short(repo_root),
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "generator": "blb_stage2_rl.baseline_bootstrap.write_baseline_request",
    }
    if rl_max_sfs:
        payload["rl_max_sfs"] = {
            str(blk): {str(node): int(sf) for node, sf in mapping.items()}
            for blk, mapping in rl_max_sfs.items()
        }
    if rl_max_fresh_sfs:
        payload["rl_max_fresh_sfs"] = {
            str(k): int(v) for k, v in rl_max_fresh_sfs.items()
        }

    tmp_path = paths["request_path"] + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)
    os.replace(tmp_path, paths["request_path"])
    return paths["request_path"]


# ---------------------------------------------------------------------------
# Response 读取 / 校验
# ---------------------------------------------------------------------------
@dataclass
class BaselineHandoverResultEntry:
    """单条 (block, layer) 的解析结果。"""
    config_name: str
    graph_key: str
    block: int
    layer: int
    success: bool
    skeleton: List[int] = field(default_factory=list)
    t_baseline: List[int] = field(default_factory=list)
    q_bits_baseline: List[int] = field(default_factory=list)
    modulus_chain: Optional[Dict[str, Any]] = None
    fusion_count: int = 0
    invalid_chain: Optional[Dict[str, Any]] = None
    cut_point_sf: List[Dict[str, Any]] = field(default_factory=list)
    effective_rotations: List[str] = field(default_factory=list)
    error_message: str = ""


@dataclass
class BaselineHandoverResult:
    """``read_baseline_response`` 的解析输出。"""
    schema: str
    request_id: str
    dataset: str
    model: str
    num_layers: int
    ok: bool
    error: Optional[str]
    results: List[BaselineHandoverResultEntry]
    aggregate_total_bits_sum: int
    aggregate_total_fusion_count: int
    aggregate_valid_block_count: int
    aggregate_invalid_block_count: int
    warnings: List[str] = field(default_factory=list)
    raw: Dict[str, Any] = field(default_factory=dict)

    @property
    def by_config_name(self) -> Dict[str, BaselineHandoverResultEntry]:
        return {r.config_name: r for r in self.results}

    @property
    def by_block_layer(self) -> Dict[tuple, BaselineHandoverResultEntry]:
        return {(int(r.block), int(r.layer)): r for r in self.results}


class BaselineHandoverError(RuntimeError):
    """读响应失败 / 校验失败时抛出。"""


def _parse_entry(
        record: Mapping[str, Any],
        index: int,
        ) -> BaselineHandoverResultEntry:
    try:
        return BaselineHandoverResultEntry(
            config_name=str(record["config_name"]),
            graph_key=str(record["graph_key"]),
            block=int(record["block"]),
            layer=int(record["layer"]),
            success=bool(record.get("success", False)),
            skeleton=[int(x) for x in (record.get("skeleton") or [])],
            t_baseline=[int(x) for x in (record.get("t_baseline") or [])],
            q_bits_baseline=[int(x) for x in (record.get("q_bits_baseline") or [])],
            modulus_chain=(
                dict(record["modulus_chain"])
                if isinstance(record.get("modulus_chain"), Mapping) else None
            ),
            fusion_count=int(record.get("fusion_count", 0)),
            invalid_chain=(
                dict(record["invalid_chain"])
                if isinstance(record.get("invalid_chain"), Mapping) else None
            ),
            cut_point_sf=[dict(x) for x in (record.get("cut_point_sf") or [])],
            effective_rotations=[
                str(x) for x in (record.get("effective_rotations") or [])
            ],
            error_message=str(record.get("error_message", "")),
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise BaselineHandoverError(
            f"results[{index}] 解析失败：{exc}（record={record!r}）"
        ) from exc


def read_baseline_response(
        repo_root: str,
        dataset: str,
        *,
        expected_request_id: Optional[str] = None,
        max_age_seconds: Optional[float] = None,
        ) -> BaselineHandoverResult:
    """读取响应 JSON 并 strict-校验。

    Args:
        repo_root:           项目根目录
        dataset:             GLUE 任务名
        expected_request_id: 校验响应的 request_id 必须匹配；None ⇒ 跳过该校验。
        max_age_seconds:     响应文件 mtime 必须在 ``now - max_age_seconds`` 之后；
                             None ⇒ 不限。用于过期响应保护。

    Raises:
        BaselineHandoverError: 文件不存在 / schema 不匹配 / 字段缺失 /
                                aggregate 计数与 results 不一致。
    """
    paths = handover_paths(repo_root, dataset)
    resp_path = paths["response_path"]
    if not os.path.isfile(resp_path):
        raise BaselineHandoverError(
            f"baseline 响应文件不存在: {resp_path}"
            f"（dataset={dataset!r}；先把 baseline_request 发给 RO 一侧）"
        )

    if max_age_seconds is not None:
        mtime = os.path.getmtime(resp_path)
        age = float(time.time() - mtime)
        if age > float(max_age_seconds):
            raise BaselineHandoverError(
                f"baseline 响应过期（age={age:.0f}s > {max_age_seconds:.0f}s）：{resp_path}"
            )

    with open(resp_path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    if not isinstance(raw, Mapping):
        raise BaselineHandoverError(
            f"baseline 响应顶层不是 dict：{type(raw).__name__}"
        )

    schema = str(raw.get("schema", ""))
    if schema != RESPONSE_SCHEMA_V1:
        raise BaselineHandoverError(
            f"baseline 响应 schema 不匹配：期望 {RESPONSE_SCHEMA_V1}，实际 {schema!r}"
        )

    request_id = str(raw.get("request_id", ""))
    if expected_request_id is not None and request_id != str(expected_request_id):
        raise BaselineHandoverError(
            f"baseline 响应 request_id 不匹配：期望 {expected_request_id!r}，"
            f"实际 {request_id!r}（说明 RO 写的是上一轮的响应）"
        )

    if str(raw.get("dataset", "")) != str(dataset):
        raise BaselineHandoverError(
            f"baseline 响应 dataset 不匹配：期望 {dataset!r}，"
            f"实际 {raw.get('dataset')!r}"
        )

    num_layers = int(raw.get("num_layers", 0))
    if num_layers <= 0:
        raise BaselineHandoverError(
            f"baseline 响应 num_layers 不合法：{num_layers!r}"
        )

    results_raw = raw.get("results")
    if not isinstance(results_raw, list):
        raise BaselineHandoverError("baseline 响应 results 字段不是 list")

    results: List[BaselineHandoverResultEntry] = []
    for idx, rec in enumerate(results_raw):
        if not isinstance(rec, Mapping):
            raise BaselineHandoverError(
                f"baseline 响应 results[{idx}] 不是 dict：{type(rec).__name__}"
            )
        results.append(_parse_entry(rec, idx))

    # 语义更新（2026-05）：(block=1, layer=0) 不再发给 RO（layer-0 block1
    # 噪声整体不安装；第一个 HE 配置视为无损）。期望 results 长度 = 5L - 1。
    # 若 RO 仍然返回 (1, 0) 这条记录，不算错误——会被接受但忽略。
    expected_n = 5 * num_layers - 1
    if len(results) not in (expected_n, expected_n + 1):
        raise BaselineHandoverError(
            f"baseline 响应 results 长度 {len(results)} != 期望 "
            f"{expected_n}（5*num_layers - 1，已排除 layer-0 block1）"
        )

    seen = set()
    for r in results:
        key = (int(r.block), int(r.layer))
        if key in seen:
            raise BaselineHandoverError(
                f"baseline 响应 results 中 (block={r.block}, layer={r.layer}) 重复"
            )
        seen.add(key)
    for layer in range(num_layers):
        for block in (1, 2, 3, 4, 5):
            # layer-0 block1 是允许缺失的（语义对齐）；其余必须有。
            if int(layer) == 0 and int(block) == 1:
                continue
            if (block, layer) not in seen:
                raise BaselineHandoverError(
                    f"baseline 响应 results 缺少 (block={block}, layer={layer})"
                )

    aggregate = raw.get("aggregate") or {}
    if not isinstance(aggregate, Mapping):
        raise BaselineHandoverError("baseline 响应 aggregate 不是 dict")
    valid_n = int(aggregate.get("valid_block_count", -1))
    invalid_n = int(aggregate.get("invalid_block_count", -1))
    if valid_n < 0 or invalid_n < 0:
        raise BaselineHandoverError(
            f"baseline 响应 aggregate 缺少 valid/invalid_block_count: {dict(aggregate)!r}"
        )
    # 允许 RO 在 aggregate 里把可选的 (block=1, layer=0) 也计进去，即多 1。
    if (valid_n + invalid_n) not in (expected_n, expected_n + 1):
        raise BaselineHandoverError(
            f"baseline 响应 aggregate {valid_n}+{invalid_n} != {expected_n}"
            f"（也不等于 {expected_n + 1} 的 tolerant-mode 值）"
        )
    actual_valid = sum(1 for r in results if r.success)
    actual_invalid = sum(1 for r in results if not r.success)
    if actual_valid != valid_n or actual_invalid != invalid_n:
        raise BaselineHandoverError(
            f"baseline 响应 aggregate ({valid_n}/{invalid_n}) 与 results "
            f"实际计数 ({actual_valid}/{actual_invalid}) 不一致"
        )

    total_bits_sum = int(aggregate.get("total_bits_sum", 0))
    total_fusion_count = int(aggregate.get("total_fusion_count", 0))

    actual_total_bits = 0
    for r in results:
        if r.success and isinstance(r.modulus_chain, Mapping):
            actual_total_bits += int(r.modulus_chain.get("total_bits", 0))
    if actual_total_bits != total_bits_sum:
        # 不抛异常 —— 只警告，因为 aggregate 是 RO 一侧自报的辅助字段
        # 但不一致是 RO 端 bug 信号，应该被人看到
        warnings_list = list(raw.get("warnings") or [])
        warnings_list.append(
            f"aggregate.total_bits_sum={total_bits_sum} 与 results 实算 "
            f"{actual_total_bits} 不一致；以 results 为准"
        )
    else:
        warnings_list = list(raw.get("warnings") or [])

    return BaselineHandoverResult(
        schema=schema,
        request_id=request_id,
        dataset=str(raw.get("dataset", dataset)),
        model=str(raw.get("model", "")),
        num_layers=num_layers,
        ok=bool(raw.get("ok", False)),
        error=(str(raw["error"]) if raw.get("error") is not None else None),
        results=results,
        aggregate_total_bits_sum=int(actual_total_bits),    # 用实算
        aggregate_total_fusion_count=int(total_fusion_count),
        aggregate_valid_block_count=actual_valid,
        aggregate_invalid_block_count=actual_invalid,
        warnings=[str(x) for x in warnings_list],
        raw=dict(raw),
    )


# ---------------------------------------------------------------------------
# Response → BaselineCostStats
# ---------------------------------------------------------------------------
def baseline_response_to_cost_stats(
        result: BaselineHandoverResult,
        *,
        baseline_avg_k: float = 13.0,
        ) -> BaselineCostStats:
    """把响应转换成 ``BaselineCostStats``，用于 ``BLBStage2Env`` reward 校准。

    转换规则：
      * ``total_bits_sum``    = result.aggregate_total_bits_sum（已重算）
      * ``total_fusion_count``= result.aggregate_total_fusion_count
      * ``avg_k``             = baseline_avg_k（K 不在 RO 计算范围；用 RL 的 max_K）
      * ``loss_*`` / ``metric*_*``：留 0；上层会用 probe 重算

    若 ``result.ok=False``，仍然返回 stats（以 valid 子集计算），但 caller 应该
    检查 ``result.ok`` 决定是否启动训练。
    """
    return BaselineCostStats(
        total_bits_sum=int(result.aggregate_total_bits_sum),
        total_fusion_count=int(result.aggregate_total_fusion_count),
        avg_k=float(baseline_avg_k),
        # 占位；上层 estimate_baseline_cost_stats / runner 会实际跑一次填充
        loss_mean=0.0,
        loss_std=0.0,
        metric1_mean=0.0,
        metric2_mean=0.0,
        metric1_std=0.0,
        metric2_std=0.0,
        typical_bits_drop=1.0,
        typical_fusion_count=1.0,
        typical_k_drop=1.0,
    )


# ---------------------------------------------------------------------------
# 自检 helpers（可被 tests 调用）
# ---------------------------------------------------------------------------
def validate_response_against_request(
        request_path: str,
        response: BaselineHandoverResult,
        ) -> List[str]:
    """对照 request 文件检查 response 一致性，返回问题列表（空 = 全部通过）。"""
    problems: List[str] = []
    try:
        with open(request_path, "r", encoding="utf-8") as f:
            req = json.load(f)
    except Exception as exc:
        return [f"无法读取 request: {exc}"]

    if str(req.get("schema", "")) != REQUEST_SCHEMA_V1:
        problems.append(f"request.schema 不是 {REQUEST_SCHEMA_V1}")
    if str(req.get("request_id", "")) != str(response.request_id):
        problems.append("request_id 不匹配 (request vs response)")
    if int(req.get("num_layers", 0)) != int(response.num_layers):
        problems.append("num_layers 不匹配")
    if str(req.get("dataset", "")) != str(response.dataset):
        problems.append("dataset 不匹配")

    s1 = req.get("stage1_config") or {}
    gelu = list(s1.get("gelu_degree_per_layer") or [])
    softmax = list(s1.get("softmax_degree_per_layer") or [])
    for r in response.results:
        if not r.success:
            continue
        layer = int(r.layer)
        block = int(r.block)
        if block == 3:
            if 0 <= layer < len(softmax):
                expected = f"block3_exp_n{int(softmax[layer])}"
                if r.graph_key != expected:
                    problems.append(
                        f"results (block=3, layer={layer}).graph_key={r.graph_key!r} "
                        f"不符 stage1.softmax[{layer}]={softmax[layer]} → 期望 {expected!r}"
                    )
        elif block == 5:
            if 0 <= layer < len(gelu):
                expected = f"block5_n{int(gelu[layer])}"
                if r.graph_key != expected:
                    problems.append(
                        f"results (block=5, layer={layer}).graph_key={r.graph_key!r} "
                        f"不符 stage1.gelu[{layer}]={gelu[layer]} → 期望 {expected!r}"
                    )
    return problems
