# Server Code Sync Report

- local_head: `6341ceab2bb15cd6e4cb0b98805bc88d7343a984`
- local_branch: `jk_standard_rl`
- remote_root: `/var/tmp/root-home/Reinforcement-For-Robustness`
- copied_count: `30`
- deleted_count: `4`
- failed_count: `0`

## Remote Status And Diff Check

```text
## jk_standard_rl...origin/jk_standard_rl
 M Paean/blb_action_eval.py
 M blb_stage2_rl/action_space.py
 M blb_stage2_rl/candidate_store.py
 M blb_stage2_rl/persistence.py
 M blb_stage2_rl/policy.py
 M blb_stage2_rl/reward.py
 M blb_stage2_rl/runner.py
 D "docs/\346\200\273\346\235\277\346\233\264\346\226\260\345\221\275\344\273\244.md"
 D reports/blb_entrypoints_grep.txt
 D reports/repo_code_config_files.txt
 D reports/repo_file_list.txt
 M scripts/blb_eval_action.py
 M scripts/blb_export_action_registry.py
 M tests/test_blb_stage2_rl_regressions.py
?? blb_stage2_rl/action_mask.py
?? blb_stage2_rl/feasibility.py
?? reports/blb_opt/trust0_manifest/
?? reports/blb_opt/trust0_registry/
?? reports/server_code_sync_report.json
?? reports/server_code_sync_report.md
?? reports/trust0_remote_test_log.txt
?? scripts/blb_make_run_manifest.py
?? tests/test_blb_action_mask.py
?? tests/test_blb_candidate_store_identity.py
?? tests/test_blb_cost_semantics.py
?? tests/test_blb_final_eval_feasibility.py
?? tests/test_blb_warmstart_resume.py
```

## Failed

- none
