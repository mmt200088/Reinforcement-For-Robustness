import json
import tempfile
import unittest

from blb_stage2_rl.baseline_bootstrap import (
    BaselineHandoverError,
    RESPONSE_SCHEMA_V1,
    baseline_response_to_cost_stats,
    handover_paths,
    read_baseline_response,
    validate_response_against_request,
    write_baseline_request,
)


class BLBBaselineBootstrapTests(unittest.TestCase):
    def _write_response(
            self,
            repo_root,
            dataset,
            request_id,
            gelu,
            softmax,
            *,
            include_layer0_block1=True,
            skip_pairs=frozenset(),
            ):
        paths = handover_paths(repo_root, dataset)
        results = []
        total_bits = 0
        total_fusion = 0
        for layer in range(len(gelu)):
            for block in (1, 2, 3, 4, 5):
                key = (block, layer)
                if key in skip_pairs:
                    continue
                if key == (1, 0) and not include_layer0_block1:
                    continue
                if block == 3:
                    graph_key = f"block3_exp_n{softmax[layer]}"
                elif block == 5:
                    graph_key = f"block5_n{gelu[layer]}"
                else:
                    graph_key = f"block{block}_{dataset}"
                bits = 1000 + layer * 10 + block
                fusion = block % 2
                total_bits += bits
                total_fusion += fusion
                results.append({
                    "config_name": f"{graph_key}_L{layer}",
                    "graph_key": graph_key,
                    "block": block,
                    "layer": layer,
                    "success": True,
                    "skeleton": [0, 1, 2],
                    "t_baseline": [1, 2, 3],
                    "q_bits_baseline": [60, 50, 40],
                    "modulus_chain": {"total_bits": bits, "q_bits": [60, 50, 40]},
                    "fusion_count": fusion,
                    "invalid_chain": None,
                    "cut_point_sf": [{"node": "ctpt", "sf": 16}],
                    "effective_rotations": [],
                    "error_message": "",
                })

        payload = {
            "schema": RESPONSE_SCHEMA_V1,
            "request_id": request_id,
            "dataset": dataset,
            "model": "bert-base",
            "num_layers": len(gelu),
            "ok": True,
            "error": None,
            "results": results,
            "aggregate": {
                "total_bits_sum": total_bits,
                "total_fusion_count": total_fusion,
                "valid_block_count": len(results),
                "invalid_block_count": 0,
            },
            "warnings": [],
        }
        with open(paths["response_path"], "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        return total_bits, total_fusion

    def test_round_trip_response_validation_and_cost_stats(self):
        with tempfile.TemporaryDirectory() as repo_root:
            dataset = "mrpc"
            request_id = "unit-test-request"
            gelu = [1, 4]
            softmax = [2, 6]
            request_path = write_baseline_request(
                repo_root,
                dataset,
                gelu,
                softmax,
                model="bert-base",
                request_id=request_id,
            )
            total_bits, total_fusion = self._write_response(
                repo_root, dataset, request_id, gelu, softmax,
            )

            result = read_baseline_response(
                repo_root, dataset, expected_request_id=request_id,
            )

            self.assertTrue(result.ok)
            self.assertEqual(len(result.results), 10)
            self.assertEqual(result.by_block_layer[(3, 1)].graph_key, "block3_exp_n6")
            self.assertEqual(result.by_block_layer[(5, 0)].graph_key, "block5_n1")
            self.assertEqual(result.aggregate_total_bits_sum, total_bits)
            self.assertEqual(result.aggregate_total_fusion_count, total_fusion)
            self.assertEqual(validate_response_against_request(request_path, result), [])

            stats = baseline_response_to_cost_stats(result, baseline_avg_k=11.0)
            self.assertEqual(stats.total_bits_sum, total_bits)
            self.assertEqual(stats.total_fusion_count, total_fusion)
            self.assertEqual(stats.avg_k, 11.0)

            with self.assertRaises(BaselineHandoverError):
                read_baseline_response(
                    repo_root, dataset, expected_request_id="wrong-request",
                )

    def test_canonical_response_may_omit_layer0_block1(self):
        with tempfile.TemporaryDirectory() as repo_root:
            dataset = "mrpc"
            request_id = "unit-test-request-no-l0-b1"
            gelu = [1, 4]
            softmax = [2, 6]
            request_path = write_baseline_request(
                repo_root,
                dataset,
                gelu,
                softmax,
                model="bert-base",
                request_id=request_id,
            )
            total_bits, total_fusion = self._write_response(
                repo_root,
                dataset,
                request_id,
                gelu,
                softmax,
                include_layer0_block1=False,
            )

            result = read_baseline_response(
                repo_root, dataset, expected_request_id=request_id,
            )

            self.assertEqual(len(result.results), 9)
            self.assertNotIn((1, 0), result.by_block_layer)
            self.assertIn((2, 0), result.by_block_layer)
            self.assertEqual(result.aggregate_valid_block_count, 9)
            self.assertEqual(result.aggregate_invalid_block_count, 0)
            self.assertEqual(result.aggregate_total_bits_sum, total_bits)
            self.assertEqual(result.aggregate_total_fusion_count, total_fusion)
            self.assertEqual(validate_response_against_request(request_path, result), [])

    def test_rejects_missing_required_non_layer0_block1_entry(self):
        with tempfile.TemporaryDirectory() as repo_root:
            dataset = "mrpc"
            request_id = "unit-test-request-missing-required"
            gelu = [1, 4]
            softmax = [2, 6]
            write_baseline_request(
                repo_root,
                dataset,
                gelu,
                softmax,
                model="bert-base",
                request_id=request_id,
            )
            self._write_response(
                repo_root,
                dataset,
                request_id,
                gelu,
                softmax,
                include_layer0_block1=False,
                skip_pairs={(2, 1)},
            )

            with self.assertRaises(BaselineHandoverError):
                read_baseline_response(
                    repo_root, dataset, expected_request_id=request_id,
                )

    def test_rejects_invalid_stage1_degree(self):
        with tempfile.TemporaryDirectory() as repo_root:
            with self.assertRaises(ValueError):
                write_baseline_request(
                    repo_root,
                    "mrpc",
                    [3],
                    [2],
                    model="bert-base",
                    request_id="bad-gelu",
                )
            with self.assertRaises(ValueError):
                write_baseline_request(
                    repo_root,
                    "mrpc",
                    [1],
                    [7],
                    model="bert-base",
                    request_id="bad-softmax",
                )


if __name__ == "__main__":
    unittest.main()
