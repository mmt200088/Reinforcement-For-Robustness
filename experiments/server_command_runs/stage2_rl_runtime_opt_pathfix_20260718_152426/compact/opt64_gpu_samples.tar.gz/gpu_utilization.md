# GPU Utilization Report

Episodes: 600
Visible devices: cuda:0, cuda:1, cuda:2, cuda:3, cuda:4
Used probe devices: cuda:0, cuda:1, cuda:2, cuda:3, cuda:4
Sampled active devices: cuda:0, cuda:1, cuda:2, cuda:3, cuda:4
Unattributed visible devices: none
Idle visible devices: none

## Probe Timing
Terminal probe mean seconds: 0.5296730319263103
Policy rollout mean seconds: 0.0
Replan/optimizer mean seconds: 0.0

## Probe Wall By Device
- cuda:0: episodes=600, mean_s=0.5296730319263103, min_s=0.5279556240420789, max_s=0.5352452020160854
- cuda:1: episodes=600, mean_s=0.5296730319263103, min_s=0.5279556240420789, max_s=0.5352452020160854
- cuda:2: episodes=600, mean_s=0.5296730319263103, min_s=0.5279556240420789, max_s=0.5352452020160854
- cuda:3: episodes=600, mean_s=0.5296730319263103, min_s=0.5279556240420789, max_s=0.5352452020160854
- cuda:4: episodes=600, mean_s=0.5296730319263103, min_s=0.5279556240420789, max_s=0.5352452020160854

## Trial Balance
- cuda:0: 600
- cuda:1: 600
- cuda:2: 600
- cuda:3: 600
- cuda:4: 600

## Nvidia SMI
- cuda:0: max_util_pct=99.0, mean_util_pct=84.8738229755179, active_sample_rate=0.9642184557438794, max_memory_mib=3285.0
- cuda:1: max_util_pct=99.0, mean_util_pct=85.1939736346516, active_sample_rate=0.9209039548022598, max_memory_mib=3720.0
- cuda:2: max_util_pct=99.0, mean_util_pct=85.77401129943503, active_sample_rate=0.9171374764595104, max_memory_mib=3720.0
- cuda:3: max_util_pct=99.0, mean_util_pct=85.5819209039548, active_sample_rate=0.9246704331450094, max_memory_mib=3720.0
- cuda:4: max_util_pct=99.0, mean_util_pct=85.50470809792844, active_sample_rate=0.9209039548022598, max_memory_mib=3720.0

## Warnings
- none
