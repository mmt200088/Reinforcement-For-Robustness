# GPU Utilization Report

Episodes: 600
Visible devices: cuda:0, cuda:1, cuda:2, cuda:3, cuda:4
Used probe devices: cuda:0, cuda:1, cuda:2, cuda:3, cuda:4
Sampled active devices: cuda:0, cuda:1, cuda:2, cuda:3, cuda:4
Unattributed visible devices: none
Idle visible devices: none

## Probe Timing
Terminal probe mean seconds: 0.5294803933027045
Policy rollout mean seconds: 0.0
Replan/optimizer mean seconds: 0.0

## Probe Wall By Device
- cuda:0: episodes=600, mean_s=0.5294803933027045, min_s=0.5272937640547752, max_s=0.5357768551912159
- cuda:1: episodes=600, mean_s=0.5294803933027045, min_s=0.5272937640547752, max_s=0.5357768551912159
- cuda:2: episodes=600, mean_s=0.5294803933027045, min_s=0.5272937640547752, max_s=0.5357768551912159
- cuda:3: episodes=600, mean_s=0.5294803933027045, min_s=0.5272937640547752, max_s=0.5357768551912159
- cuda:4: episodes=600, mean_s=0.5294803933027045, min_s=0.5272937640547752, max_s=0.5357768551912159

## Trial Balance
- cuda:0: 600
- cuda:1: 600
- cuda:2: 600
- cuda:3: 600
- cuda:4: 600

## Nvidia SMI
- cuda:0: max_util_pct=99.0, mean_util_pct=81.10363636363637, active_sample_rate=0.9272727272727272, max_memory_mib=5314.0
- cuda:1: max_util_pct=99.0, mean_util_pct=82.63272727272727, active_sample_rate=0.8836363636363637, max_memory_mib=6685.0
- cuda:2: max_util_pct=99.0, mean_util_pct=83.21272727272728, active_sample_rate=0.9036363636363637, max_memory_mib=6685.0
- cuda:3: max_util_pct=99.0, mean_util_pct=82.09818181818181, active_sample_rate=0.8836363636363637, max_memory_mib=6685.0
- cuda:4: max_util_pct=99.0, mean_util_pct=82.11090909090909, active_sample_rate=0.8854545454545455, max_memory_mib=6685.0

## Warnings
- none
