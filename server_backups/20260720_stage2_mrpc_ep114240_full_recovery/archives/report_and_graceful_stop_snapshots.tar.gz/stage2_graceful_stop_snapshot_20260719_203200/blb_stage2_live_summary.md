# BLB Stage-2 RL Live Summary

- Run: `s1t0.001_s2t0.001_s2st2.0__dual_resource_natconv_fresh_20260718_190924`
- Profile: `mrpc`
- Phase: PPO training (12-step layerwise robust)
- Updated at: 2026-07-19T20:28:48.222994
- Elapsed seconds: 91107.788000
- Episode: 114240 / unbounded
- PPO updates: 952

## Reward

- Last reward: +1.083503
- Recent reward mean: +0.387228
- Best reward: +1.250483
- Best episode: n/a
- Last priority: 3
- Last invalid: False

## Last Terminal Metrics


## Last PPO Update

- `policy_loss`: -0.0063208225183188915
- `value_loss`: 0.30634334683418274
- `entropy`: 5.8701629638671875
- `clip_fraction`: 0.029161544516682625
- `window_mean_return`: 0.31878239956572707
- `window_mean_invalid`: 0.0
- `approx_kl`: 0.00265291053801775
- `lr`: 5e-05
- `ent_coef`: 0.0

## Key Artifacts

- Status JSON: `blb_stage2_status.json`
- Live summary: `blb_stage2_live_summary.md`
- Episodes: `diagnostics/episodes.jsonl`
- PPO updates: `diagnostics/ppo_updates.jsonl`
- Diagnostics summary: `diagnostics/diagnostics_summary.md`
- Details batches: `details/`
- Training curve: `blb_stage2_training_curve.png`
- Entropy curve: `blb_stage2_entropy_curve.png`
- Final report: `blb_stage2_report.md`
