#!/usr/bin/env bash
set -euo pipefail
cd "/hy-tmp/rfr_runtime_optimization"
RUN="Parting Chapter/persistent/rl/bert-base/mrpc/s1t0.001_s2t0.001_s2st2.0__dual_resource_natconv_fresh_20260718_190924"

# Resume the exact persistent run. Do not add --fresh-start/--fresh.
python rl_tune.py \
  --base_model textattack/bert-base-uncased-MRPC \
  --data_path mrpc \
  --output_dir "$RUN" \
  --batch_size 64 --micro_batch_size 64 --num_epochs 1 \
  --learning_rate 2e-4 --cutoff_len 256 --val_set_size 120 --eval_step 80 \
  --adapter_name lora \
  --target_modules '["q_proj", "k_proj", "v_proj", "up_proj", "down_proj"]' \
  --stage1_rl_episodes 51000 --stage2_rl_episodes 0 \
  --stage1_rl_episodes_specified false --stage2_rl_episodes_specified true \
  --ppo_update_interval 120 --use_ist \
  --final_eval_config_source search \
  --final_eval_config_path glue_final_configs_best_ppo.json \
  --manual_stage1_gelu '' --manual_stage1_softmax '' --manual_stage2_noise '' \
  --stage2_fixed_config_source all4 --stage2_fixed_config_path '' \
  --stage2_manual_gelu '' --stage2_manual_softmax '' \
  --final_eval_random_seed 42 \
  --final_eval_permutation_trials 0 --final_eval_cost_equivalent_trials 0 \
  --final_eval_budget_equivalent_trials 0 \
  --final_eval_stage1_budget_trials 10 --final_eval_stage2_budget_trials 10 \
  --final_eval_repeat_n 1 --final_eval_preset default \
  --skip_noise_rl false --skip_stage1_rl true --skip_final_eval true \
  --final_eval_only false --resume_run_dir "$RUN" \
  --stage1_rl_lr 1e-4 --stage2_rl_lr 5e-5 \
  --stage1_accuracy_tolerance 0.001 \
  --stage2_limit_tolerance 0.001 \
  --stage2_stability_tolerance 1.2 \
  --stage2_stability_multiplier 2.0 \
  --stage2_k_trials 5 --stage2_probe_size 256 \
  --stage2_rl_variant blb_v3 \
  --blb_v3_inproc_rescale_optimizer_root Rescale_optimizer \
  --blb_v3_rollout_size 120 \
  --decoupled_layout false --stage1_run_id '' \
  --blb_v3_reward_devices 0,1,2,3,4 \
  --blb_v3_eval_interval 100 --blb_v3_save_interval 200 \
  --blb_v3_calibrate_baseline_samples 8 \
  --blb_v3_online_k_trials 5 \
  --blb_v3_promotion_validation_trials 25 \
  --blb_v3_final_selection_validation_trials 25 \
  --blb_v3_baseline_groups 5 --blb_v3_baseline_trials_per_group 5 \
  --blb_v3_constraint_bootstrap_samples 4096 \
  --blb_v3_online_constraint_probability 0.50 \
  --blb_v3_promotion_constraint_probability 0.80 \
  --blb_v3_final_constraint_probability 0.95 \
  --blb_v3_sequential_rl true \
  --blb_v3_sequential_invalid_penalty 1.0 \
  --blb_v3_sequential_cost_shaping_coeff 0.0 \
  --blb_v3_sequential_fusion_shaping_coeff 0.0 \
  --rl_algo ppo --blb_v3_substage_mode false \
  --blb_v3_fusion_count_action true \
  --blb_v3_decision_granularity layer \
  --blb_v3_reward_design robust_constrained
