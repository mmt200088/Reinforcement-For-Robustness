# BLB Stage-2 RL Live Summary

- Run: `s1t0.001_s2t0.001_s2st2.0__dual_resource_natconv_fresh_20260718_190924`
- Profile: `mrpc`
- Phase: PPO training (12-step layerwise robust)
- Updated at: 2026-07-19T14:00:44.430118
- Elapsed seconds: 67823.995000
- Episode: 83880 / unbounded
- PPO updates: 699

## Reward

- Last reward: -3.242876
- Recent reward mean: +0.385704
- Best reward: +1.288279
- Best episode: n/a
- Last priority: 1
- Last invalid: False

## Last Terminal Metrics


## Last PPO Update

- `policy_loss`: -0.003399198642000556
- `value_loss`: 0.2788574993610382
- `entropy`: 6.405259609222412
- `clip_fraction`: 0.023061603307724
- `window_mean_return`: 0.3969320411659398
- `window_mean_invalid`: 0.0
- `approx_kl`: 0.002291871700435877
- `lr`: 5e-05
- `ent_coef`: 0.0

## Key Artifacts

- Status JSON: `blb_stage2_status.json`
- Live summary: `blb_stage2_live_summary.md`
- Episodes: `diagnostics/episodes.jsonl`
- PPO updates: `diagnostics/ppo_updates.jsonl`
- Diagnostics summary: `diagnostics/diagnostics_summary.md`
- Details batches: `details/`
- Training curve: `blb_stage2_training_curve.png`
- Entropy curve: `blb_stage2_entropy_curve.png`
- Final report: `blb_stage2_report.md`
